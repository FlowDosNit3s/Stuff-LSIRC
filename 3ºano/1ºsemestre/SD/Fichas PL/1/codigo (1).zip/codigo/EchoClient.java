import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

/**
 * Cliente Echo: liga-se a um servidor Echo, envia cada linha escrita no
 * terminal e mostra a linha devolvida pelo servidor.
 *
 * Uso: java EchoClient [host] [porto]
 * Valores por omissão: host = localhost, porto = 5050.
 * Para terminar, feche a entrada (Ctrl+D em Linux/macOS, Ctrl+Z Enter em Windows).
 */
public class EchoClient {

    public static void main(String[] args) {
        String host = args.length >= 1 ? args[0] : "localhost";
        int porto = args.length >= 2 ? Integer.parseInt(args[1]) : 5050;

        try (Socket echoSocket = new Socket(host, porto);
             PrintWriter out = new PrintWriter(
                     echoSocket.getOutputStream(), true, StandardCharsets.UTF_8);
             BufferedReader in = new BufferedReader(new InputStreamReader(
                     echoSocket.getInputStream(), StandardCharsets.UTF_8));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Ligado a " + host + ":" + porto
                    + ". Sair: Ctrl+D (Linux/macOS) ou Ctrl+Z+Enter (Windows).");

            String linhaUtilizador;
            while ((linhaUtilizador = stdIn.readLine()) != null) {
                out.println(linhaUtilizador);
                String resposta = in.readLine();
                if (resposta == null) {
                    System.out.println("O servidor fechou a ligação.");
                    break;
                }
                System.out.println("eco: " + resposta);
            }

        } catch (UnknownHostException e) {
            System.err.println("Não foi possível encontrar o servidor: " + host);
            System.exit(1);
        } catch (ConnectException e) {
            System.err.println("Não foi possível ligar a " + host + ":" + porto
                    + " - o servidor está em baixo? (" + e.getMessage() + ")");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Erro de I/O na ligação a " + host + ":" + porto + ": " + e.getMessage());
            System.exit(1);
        }
    }
}
