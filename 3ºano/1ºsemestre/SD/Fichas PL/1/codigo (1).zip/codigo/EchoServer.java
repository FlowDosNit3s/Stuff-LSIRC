import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Servidor Echo: aceita uma ligação TCP de cada vez e devolve ao cliente,
 * linha a linha, exatamente o que recebe.
 *
 * Uso: java EchoServer [porto]
 * Porto por omissão: 5050.
 */
public class EchoServer {

    public static void main(String[] args) {
        int porto = 5050;
        if (args.length >= 1) {
            porto = Integer.parseInt(args[0]);
        }

        // try-with-resources: o ServerSocket é sempre fechado, mesmo em caso de erro.
        try (ServerSocket serverSocket = new ServerSocket(porto)) {
            System.out.println("Servidor Echo à escuta no porto " + porto + "...");

            // Ciclo: aceita um cliente, atende-o até ele desligar, e volta a aceitar.
            // Nota: isto é um servidor SEQUENCIAL — só atende um cliente de cada vez.
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     PrintWriter out = new PrintWriter(
                             clientSocket.getOutputStream(), true, StandardCharsets.UTF_8);
                     BufferedReader in = new BufferedReader(new InputStreamReader(
                             clientSocket.getInputStream(), StandardCharsets.UTF_8))) {

                    System.out.println("Cliente ligado: " + clientSocket.getRemoteSocketAddress());

                    String linha;
                    while ((linha = in.readLine()) != null) {
                        System.out.println("Recebido: " + linha);
                        out.println(linha);
                    }

                    System.out.println("Cliente desligou: " + clientSocket.getRemoteSocketAddress());
                } catch (IOException e) {
                    System.err.println("Erro na ligação com um cliente: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Não foi possível iniciar o servidor no porto " + porto + ": " + e);
            System.exit(1);
        }
    }
}
