package model.event;

import com.ppstudios.footballmanager.api.contracts.event.IEvent;
import com.ppstudios.footballmanager.api.contracts.team.ITeam;
import com.ppstudios.footballmanager.api.contracts.player.IPlayer;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class CornerKick extends Event {
    private ITeam team;
    private IPlayer taker;
    private boolean goalScored;

    public CornerKick(String description, int minute, ITeam team, IPlayer taker) {
        super(description, minute);
        this.team = team;
        this.taker = taker;
        this.goalScored = false;
    }

    public ITeam getTeam() {
        return team;
    }

    public IPlayer getTaker() {
        return taker;
    }

    public boolean isGoalScored() {
        return goalScored;
    }

    public void setGoalScored(boolean goalScored) {
        this.goalScored = goalScored;
    }

    @Override
    public void exportToJson() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(new File("cornerKick.json"), this);
    }
}
