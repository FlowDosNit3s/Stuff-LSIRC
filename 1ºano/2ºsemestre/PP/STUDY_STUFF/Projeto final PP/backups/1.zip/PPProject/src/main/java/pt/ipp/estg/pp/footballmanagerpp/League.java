package pt.ipp.estg.pp.footballmanagerpp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class League {
    private List<Team> teams = new ArrayList<>();
    private List<List<Match>> fixtures = new ArrayList<>();
    private int currentRound = 0;

    public League() {
        initializePortugueseLeague();
        generateRoundRobinFixtures();
    }

    private void initializePortugueseLeague() {
        String[] teamNames = {
                "Sporting CP", "Benfica", "FC Porto", "SC Braga", "Vitória Guimarães",
                "Santa Clara", "Casa Pia", "Famalicão", "Estoril Praia", "Rio Ave",
                "Moreirense", "Arouca", "Nacional", "Gil Vicente", "Estrela da Amadora",
                "AVS", "Farense", "Boavista"
        };

        for (String name : teamNames) {
            Team team = new Team(name);
            if (name.equals("Estoril Praia")) {
                team.initializeEstoril();
            }
            teams.add(team);
        }
    }

    private void generateRoundRobinFixtures() {
        int numTeams = teams.size();
        int rounds = (numTeams - 1) * 2;
        int matchesPerRound = numTeams / 2;

        for (int round = 0; round < rounds / 2; round++) {
            List<Match> roundMatches = new ArrayList<>();
            for (int i = 0; i < matchesPerRound; i++) {
                Team home = teams.get((round + i) % (numTeams - 1));
                Team away = teams.get((numTeams - 1 - i + round) % (numTeams - 1));
                if (i == 0) away = teams.get(numTeams - 1);
                roundMatches.add(new Match(home, away));
            }
            fixtures.add(roundMatches);
        }

        for (int round = 0; round < rounds / 2; round++) {
            List<Match> roundMatches = new ArrayList<>();
            for (Match match : fixtures.get(round)) {
                roundMatches.add(new Match(match.getAway(), match.getHome()));
            }
            fixtures.add(roundMatches);
        }
    }

    public List<Match> getCurrentRoundMatches() {
        return currentRound < fixtures.size() ? fixtures.get(currentRound) : Collections.emptyList();
    }

    public void advanceRound() {
        currentRound++;
    }

    public List<Team> getTeams() {
        return teams;
    }

    public int getCurrentRound() {
        return currentRound;
    }
}
