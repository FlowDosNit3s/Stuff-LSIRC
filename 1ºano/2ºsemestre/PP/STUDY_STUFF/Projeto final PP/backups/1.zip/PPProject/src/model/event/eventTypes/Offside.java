package model.event;

import com.ppstudios.footballmanager.api.contracts.event.IEvent;
import com.ppstudios.footballmanager.api.contracts.team.ITeam;
import com.ppstudios.footballmanager.api.contracts.player.IPlayer;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class Offside extends Event {
    private ITeam team;
    private IPlayer player;
    private double distanceOffside;

    public Offside(String description, int minute, ITeam team, IPlayer player) {
        super(description, minute);
        this.team = team;
        this.player = player;
        this.distanceOffside = 0.0;
    }

    public ITeam getTeam() {
        return team;
    }

    public IPlayer getPlayer() {
        return player;
    }

    public double getDistanceOffside() {
        return distanceOffside;
    }

    public void setDistanceOffside(double distanceOffside) {
        this.distanceOffside = distanceOffside;
    }

    @Override
    public void exportToJson() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(new File("offside.json"), this);
    }
}
