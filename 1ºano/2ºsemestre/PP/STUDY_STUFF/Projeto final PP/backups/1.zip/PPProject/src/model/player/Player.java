package model.player;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ppstudios.footballmanager.api.contracts.player.IPlayer;
import com.ppstudios.footballmanager.api.contracts.player.PreferredFoot;
import data.Exporter;

import java.io.IOException;
import java.time.LocalDate;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "name",
        "birthDate",
        "nationality",
        "basePosition",
        "photo",
        "number"
})
public class Player implements IPlayer {
    @JsonProperty("name")
    private String name;

    @JsonProperty("birthDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate birthDate;

    @JsonProperty("nationality")
    private String nationality;

    @JsonProperty("basePosition")
    @JsonDeserialize(using = PlayerPositionDeserializer.class)
    private IPlayerPosition position;

    @JsonProperty("photo")
    private String photo;

    @JsonProperty("number")
    private int number;

    private int shooting = 50;
    private int passing = 50;
    private int stamina = 50;
    private int speed = 50;
    private int defense = 50;
    private int goalkeeping = 50;
    private float height = 1.75f;
    private float weight = 70.0f;
    private PreferredFoot preferredFoot = PreferredFoot.RIGHT;
    private String clubCode;

    @JsonCreator
    public Player(
            @JsonProperty("name") String name,
            @JsonProperty("birthDate") LocalDate birthDate,
            @JsonProperty("nationality") String nationality,
            @JsonProperty("basePosition") IPlayerPosition position,
            @JsonProperty("photo") String photo,
            @JsonProperty("number") int number,
            @JsonProperty(value = "shooting", defaultValue = "50") int shooting,
            @JsonProperty(value = "passing", defaultValue = "50") int passing,
            @JsonProperty(value = "stamina", defaultValue = "50") int stamina,
            @JsonProperty(value = "speed", defaultValue = "50") int speed,
            @JsonProperty(value = "defense", defaultValue = "50") int defense,
            @JsonProperty(value = "goalkeeping", defaultValue = "50") int goalkeeping,
            @JsonProperty(value = "height", defaultValue = "1.75") float height,
            @JsonProperty(value = "weight", defaultValue = "70.0") float weight,
            @JsonProperty(value = "preferredFoot", defaultValue = "RIGHT") PreferredFoot preferredFoot,
            @JsonProperty("clubCode") String clubCode) {

        this.name = name;
        this.birthDate = birthDate;
        this.nationality = nationality;
        this.position = position;
        this.photo = photo;
        this.number = number;
        this.shooting = shooting;
        this.passing = passing;
        this.stamina = stamina;
        this.speed = speed;
        this.defense = defense;
        this.goalkeeping = goalkeeping;
        this.height = height;
        this.weight = weight;
        this.preferredFoot = preferredFoot;
        this.clubCode = clubCode;
    }
}


@Override
    public String getName() {
        return name;
    }

    @Override
    public LocalDate getBirthDate() {
        return birthDate;
    }

    @Override
    public int getAge() {
        LocalDate now = LocalDate.now();
        int years = now.getYear() - birthDate.getYear();

        if (now.getMonthValue() < birthDate.getMonthValue() ||
                (now.getMonthValue() == birthDate.getMonthValue() && now.getDayOfMonth() < birthDate.getDayOfMonth())) {
            years--;
        }

        return years;
    }

    @Override
    public String getNationality() {
        return nationality;
    }

    @Override
    public void setPosition(IPlayerPosition playerPosition) {
        if (playerPosition == null) {
            throw new IllegalArgumentException("Position cannot be null.");
        }
        this.position = playerPosition;
    }

    @Override
    public String getPhoto() {
        return photo;
    }

    @Override
    public int getNumber() {
        return number;
    }

    @Override
    public int getShooting() {
        return shooting;
    }

    @Override
    public int getPassing() {
        return passing;
    }

    @Override
    public int getStamina() {
        return stamina;
    }

    @Override
    public int getSpeed() {
        return speed;
    }

    public int getDefense() {
        return defense;
    }
    public int getGoalkeeping() {
        return goalkeeping;
    }

    @Override
    public IPlayerPosition getPosition() {

        return position;
    }

    @Override
    public float getHeight() {

        return height;
    }

    @Override
    public float getWeight() {

        return weight;
    }

    @Override
    public PreferredFoot getPreferredFoot() {

        return preferredFoot;
    }

    public  String getClub() {
        return this.clubCode;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Player)) return false;
        Player player = (Player) obj;
        return this.name.equals(player.name) && this.birthDate.equals(player.birthDate);
    }

    @Override
    public String toString() {
        return "Player: " + name + " \nAge: " + getAge() + " \nNationality: " + nationality +
                " \nPosition: " + position.getDescription() + " \nNumber: " + number +
                " \nSkills: \n-Shooting: " + shooting + " \n-Passing: " + passing +
                " \n-Stamina: " + stamina + " \n-Speed: " + speed + "\n-Defense: " + defense + " \n-Goalkeeping: " + goalkeeping +
                " \n-Height: " +  String.format("%.2f", height) + "m \n-Weight: " +  String.format("%.2f", weight) +
                "kg \n-Preferred Foot: " + preferredFoot + "  \n-Strength: " + getStrength() + "\n";
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public int getStrength() {
        return(shooting+speed+stamina+passing+defense+goalkeeping) / 5;
    }

    @Override
    public void exportToJson() throws IOException {
        Exporter.exportPlayer(this);
    }
}