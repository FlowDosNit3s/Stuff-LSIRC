package pt.ipp.estg.pp.footballmanagerpp;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static League league;
    private static Team userTeam;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeGame();
        while(true) {
            System.out.println("\n=== ESTORIL MANAGER 2024 ===");
            System.out.println("1. Simular Próxima Jornada");
            System.out.println("2. Sair");
            System.out.print("Escolha: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch(choice) {
                case 1: simulateRound(); break;
                case 2: System.exit(0);
                default: System.out.println("Opção inválida!");
            }
        }
    }

    private static void initializeGame() {
        league = new League();
        userTeam = league.getTeams().stream()
                .filter(t -> t.getName().equals("Estoril Praia"))
                .findFirst()
                .get();
    }

    private static void simulateRound() {
        List<Match> currentRound = league.getCurrentRoundMatches();
        if (currentRound.isEmpty()) {
            System.out.println("\nTemporada terminada!");
            return;
        }

        System.out.println("\n=== JORNADA " + (league.getCurrentRound() + 1) + " ===");

        currentRound.forEach(match -> {
            match.simulate();
            if (isUserMatch(match)) {
                showUserMatchDetails(match);
            } else {
                showOtherMatchResult(match);
            }
        });

        league.advanceRound();
        System.out.println("\n=== FIM DA JORNADA ===");
    }

    private static boolean isUserMatch(Match match) {
        return match.getHome().equals(userTeam) || match.getAway().equals(userTeam);
    }

    private static void showUserMatchDetails(Match match) {
        System.out.println("\n=== SEU JOGO ===");
        System.out.printf("%s %d - %d %s%n",
                match.getHome().getName(),
                match.getHomeScore(),
                match.getAwayScore(),
                match.getAway().getName());

        System.out.println("\nEventos:");
        match.getEvents().forEach(System.out::println);
    }

    private static void showOtherMatchResult(Match match) {
        System.out.printf("%s %d - %d %s%n",
                match.getHome().getName(),
                match.getHomeScore(),
                match.getAwayScore(),
                match.getAway().getName());
    }
}
