package pt.ipp.estg.pp.footballmanagerpp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Match {
    private Team home;
    private Team away;
    private int homeScore;
    private int awayScore;
    private List<String> events = new ArrayList<>();
    private Random random = new Random();

    public Match(Team home, Team away) {
        this.home = home;
        this.away = away;
    }

    public void simulate() {
        homeScore = random.nextInt(5);
        awayScore = random.nextInt(5);
        generateEvents();
    }

    private void generateEvents() {
        String[] players = {"André Franco", "Rui Fonte", "João Gamboa"};
        for (int i = 0; i < homeScore + awayScore; i++) {
            events.add((random.nextInt(90) + 1) + "' ⚽ " + players[random.nextInt(players.length)]);
        }
        if (random.nextDouble() < 0.3) {
            events.add((random.nextInt(90) + 1) + "' 🟡 " + players[random.nextInt(players.length)]);
        }
    }

    public List<String> getEvents() {
        return events;
    }

    public Team getHome() {
        return home;
    }

    public Team getAway() {
        return away;
    }

    public int getHomeScore() {
        return homeScore;
    }

    public int getAwayScore() {
        return awayScore;
    }
}
