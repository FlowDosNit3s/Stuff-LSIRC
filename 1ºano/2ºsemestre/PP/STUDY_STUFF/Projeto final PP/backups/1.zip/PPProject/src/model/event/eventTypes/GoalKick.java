package model.event;

import com.ppstudios.footballmanager.api.contracts.event.IEvent;
import com.ppstudios.footballmanager.api.contracts.team.ITeam;
import com.ppstudios.footballmanager.api.contracts.player.IPlayer;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class GoalKick extends Event {
    private ITeam team;
    private IPlayer goalkeeper;
    private double kickDistance;

    public GoalKick(String description, int minute, ITeam team, IPlayer goalkeeper) {
        super(description, minute);
        this.team = team;
        this.goalkeeper = goalkeeper;
        this.kickDistance = 0.0;
    }

    public ITeam getTeam() {
        return team;
    }

    public IPlayer getGoalkeeper() {
        return goalkeeper;
    }

    public double getKickDistance() {
        return kickDistance;
    }

    public void setKickDistance(double kickDistance) {
        this.kickDistance = kickDistance;
    }

    @Override
    public void exportToJson() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(new File("goalKick.json"), this);
    }
}
