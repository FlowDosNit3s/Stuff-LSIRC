package pt.ipp.estg.pp.footballmanagerpp;

public class Player {
    public String firstName;
    public String lastName;
    public String position;
    public int number;
    public int goals;
    public int yellowCards;
    public int redCards;

    public Player(String firstName, String lastName, String position, int number) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.number = number;
        this.goals = 0;
        this.yellowCards = 0;
        this.redCards = 0;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }
}
