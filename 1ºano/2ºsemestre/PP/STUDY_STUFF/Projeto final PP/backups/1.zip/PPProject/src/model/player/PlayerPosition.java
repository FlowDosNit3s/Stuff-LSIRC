package model.player;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ppstudios.footballmanager.api.contracts.player.IPlayerPosition;

public class PlayerPosition implements IPlayerPosition {
    private final PlayerPositionType type;

    @JsonCreator
    public PlayerPosition(@JsonProperty("basePosition") String type) {
        this.type = PlayerPositionType.fromString(type);
    }

    @Override
    public String getDescription() {
        return type.getPlayerPositionType();
    }

    public PlayerPositionType getType() {
        return type;
    }
}
