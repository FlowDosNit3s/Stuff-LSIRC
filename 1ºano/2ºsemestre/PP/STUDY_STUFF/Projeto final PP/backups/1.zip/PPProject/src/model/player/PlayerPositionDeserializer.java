package model.player;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;

public class PlayerPositionDeserializer extends JsonDeserializer<IPlayerPosition> {
    @Override
    public IPlayerPosition deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        String position = p.getText();
        return new PlayerPosition(position);
    }
}
