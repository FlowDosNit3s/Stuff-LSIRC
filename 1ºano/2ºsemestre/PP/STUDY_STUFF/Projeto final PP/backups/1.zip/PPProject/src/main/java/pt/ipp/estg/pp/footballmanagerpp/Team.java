package pt.ipp.estg.pp.footballmanagerpp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Team {
    public String name;
    public Player[] startingXI;
    public Player[] substitutes;
    public Player[] reserves;
    public int gamesPlayed;
    public int goalsScored;
    public int goalsConceded;
    public int points;

    public Team(String name) {
        this.name = name;
        this.startingXI = new Player[11];
        this.substitutes = new Player[7];
        this.reserves = new Player[5];
        this.gamesPlayed = 0;
        this.goalsScored = 0;
        this.goalsConceded = 0;
        this.points = 0;
    }

    public void initializeEstoril() {
        startingXI[0] = new Player("Pedro", "Silva", "GK", 1);
        startingXI[1] = new Player("Joãozinho", "", "RB", 2);
        startingXI[2] = new Player("Bernardo", "Vital", "CB", 3);
        startingXI[3] = new Player("Lucas", "Áfrico", "CB", 4);
        startingXI[4] = new Player("Tiago", "Araújo", "LB", 5);
        startingXI[5] = new Player("João", "Gamboa", "CM", 6);
        startingXI[6] = new Player("Francisco", "Geraldes", "CM", 8);
        startingXI[7] = new Player("Rafik", "Guitane", "RM", 7);
        startingXI[8] = new Player("João", "Marques", "LM", 11);
        startingXI[9] = new Player("André", "Franco", "ST", 9);
        startingXI[10] = new Player("Rui", "Fonte", "ST", 10);
        // Substitutos e reservas podem ser inicializados posteriormente
    }
}

