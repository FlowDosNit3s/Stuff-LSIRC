package crypto;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Provides key derivation utilities for cryptographic operations.
 * 
 * This class uses SHA-256 hash function to derive a 256-bit key from a character array password.
 *
 * @author Diogo Fernando Águia Costa
 * Number: 8240696
 * Class: LSIRC T1
 */
public class KeyDerivation {

    /**
     * Derives a 256-bit AES key from a given password using SHA-256.
     *
     * Note: This method simply hashes the password using SHA-256 without using a salt or an advanced key 
     * derivation function (such as PBKDF2, bcrypt, or scrypt), so it is recommended only for demonstration or 
     * applications where strong password protection is not required.
     *
     * @param password The password as a character array.
     * @return The derived 256-bit key as a byte array.
     * @throws NoSuchAlgorithmException If SHA-256 is not available on the platform.
     */
    public static byte[] deriveKey(char[] password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(new String(password).getBytes());
        return md.digest();
    }
}