package crypto;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Arrays;

/**
 * Provides utility methods for encryption and decryption using AES/GCM/NoPadding.
 * This class supports both text (with Base64 encoding) and raw byte array operations.
 * 
 * Each encryption operation generates a new 12-byte IV, prepending it to the ciphertext.
 * For decryption, the IV is extracted from the beginning of the data.
 * 
 * All methods require a 128, 192 or 256-bit AES key.
 *
 * @author Diogo Fernando Águia Costa
 * Number: 8240696
 * Class: LSIRC T1
 */
public class AESCipher {

    /**
     * Encrypts a plaintext String using AES-GCM and returns the result as a Base64-encoded String.
     * A random 12-byte IV is generated for each operation.
     *
     * @param plaintext The text to encrypt.
     * @param encKey The AES encryption key.
     * @return The encrypted text encoded with Base64, with the IV prepended.
     * @throws Exception If encryption fails.
     */
    public static String encryptText(String plaintext, byte[] encKey) throws Exception {
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
        SecretKeySpec key = new SecretKeySpec(encKey, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);
        byte[] encrypted = cipher.doFinal(plaintext.getBytes());
        byte[] result = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, result, 0, iv.length);
        System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
        return Base64.getEncoder().encodeToString(result);
    }

    /**
     * Decrypts a Base64-encoded String that was encrypted with AES-GCM and {@link #encryptText(String, byte[])}.
     *
     * @param ciphertext The Base64-encoded ciphertext with the IV prepended.
     * @param encKey The AES decryption key (must be the same used for encryption).
     * @return The decrypted plaintext String.
     * @throws Exception If decryption fails.
     */
    public static String decryptText(String ciphertext, byte[] encKey) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(ciphertext);
        byte[] iv = Arrays.copyOfRange(decoded, 0, 12);
        byte[] ciphertextBytes = Arrays.copyOfRange(decoded, 12, decoded.length);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
        SecretKeySpec key = new SecretKeySpec(encKey, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
        byte[] decrypted = cipher.doFinal(ciphertextBytes);
        return new String(decrypted);
    }

    /**
     * Encrypts a byte array using AES-GCM and returns the result with the IV prepended.
     * A random 12-byte IV is generated for each operation.
     *
     * @param input The byte array to encrypt.
     * @param encKey The AES encryption key.
     * @return The encrypted byte array with the IV prepended.
     * @throws Exception If encryption fails.
     */
    public static byte[] encryptBytes(byte[] input, byte[] encKey) throws Exception {
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
        SecretKeySpec key = new SecretKeySpec(encKey, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);
        byte[] encrypted = cipher.doFinal(input);
        byte[] result = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, result, 0, iv.length);
        System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
        return result;
    }

    /**
     * Decrypts a byte array that was encrypted with AES-GCM and {@link #encryptBytes(byte[], byte[])}.
     *
     * @param sourceArray The encrypted byte array with the IV prepended.
     * @param encKey The AES decryption key (must be the same used for encryption).
     * @return The decrypted byte array.
     * @throws Exception If decryption fails.
     */
    public static byte[] decryptBytes(byte[] sourceArray, byte[] encKey) throws Exception {
        byte[] iv = Arrays.copyOfRange(sourceArray, 0, 12);
        byte[] ciphertext = Arrays.copyOfRange(sourceArray, 12, sourceArray.length);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
        SecretKeySpec key = new SecretKeySpec(encKey, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
        return cipher.doFinal(ciphertext);
    }
}