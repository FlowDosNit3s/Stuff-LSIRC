package util;

import javax.swing.*;
import java.awt.*;

/**
 * Utility class for common GUI component creation and manipulation.
 *
 * @author Diogo Fernando Águia Costa
 * Number: 8240696
 * Class: LSIRC T1
 */
public class GuiUtils {

    /**
     * Creates a JLabel with a specific style.
     *
     * @param text The text to be displayed by the label.
     * @return A styled {@link JLabel} with the provided text.
     */
    public static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.decode("#2D2D2D"));
        label.setFont(new Font("Helvetica", Font.PLAIN, 12));
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        return label;
    }

    /**
     * Creates a JTextField that is uneditable, with consistent styling.
     *
     * @return An uneditable and styled {@link JTextField}.
     */
    public static JTextField createUneditableTextField() {
        JTextField textField = new JTextField(100);
        textField.setEditable(false);
        textField.setBackground(Color.decode("#FFFFFF"));
        textField.setForeground(Color.decode("#000000"));
        textField.setFont(new Font("Helvetica", Font.PLAIN, 12));
        return textField;
    }

    /**
     * Adds a vertical empty space to a container.
     *
     * @param container The container to which the empty space will be added.
     * @param height    The height of the empty space in pixels.
     */
    public static void addEmptySpace(Container container, int height) {
        container.add(Box.createRigidArea(new Dimension(0, height)));
    }
}