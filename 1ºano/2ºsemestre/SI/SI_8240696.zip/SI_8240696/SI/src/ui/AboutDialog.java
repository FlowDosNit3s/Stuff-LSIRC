package ui;

import javax.swing.*;
import java.awt.*;

/**
 * Displays an information dialog about the AES-256-GCM Encryptor/Decryptor application.
 * 
 * This dialog shows details about the cryptography choice, references, author, and a background watermark,
 * and features a dark, modern UI style.
 *
 * @author Diogo Fernando Águia Costa
 * Number: 8240696
 * Class: LSIRC T1
 */
public class AboutDialog extends JDialog {

    /**
     * Constructs the About dialog.
     *
     * @param parent The parent JFrame window.
     */
    public AboutDialog(JFrame parent) {
        super(parent, "About AES-256-GCM Encryptor / Decryptor", true);
        setSize(775, 460);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Create the main panel with a watermark background
        WatermarkPanel mainPanel = new WatermarkPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setOpaque(false);

        // Labels and text fields
        JLabel label1 = createDarkLabel("AES-256-GCM Encryptor / Decryptor");
        JLabel label2 = createDarkLabel("Reasons for choosing AES-256-GCM:");
        JLabel label3 = createDarkLabel("• Using 256 bits demonstrates increased security.");
        JLabel label4 = createDarkLabel("• Galois/Counter Mode provides excellent security by preventing alteration of encrypted data.");
        JLabel label5 = createDarkLabel("Main knowledge source");
        JLabel label6 = createDarkLabel("Explanatory video about AES-GCM");
        JLabel label7 = createDarkLabel("IPP ESTG LSIRC");
        JLabel label8 = createDarkLabel("Diogo Costa, 8240696");
        JLabel label9 = createDarkLabel("Information Security, 2024/2025");

        JTextField textField1 = createDarkTextField("https://www.youtube.com/@Computerphile");
        JTextField textField2 = createDarkTextField("https://www.youtube.com/watch?v=-fpVv_T4xwA&t=629s");

        JButton exitButton = new JButton("Close");
        styleDarkButton(exitButton);
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        exitButton.addActionListener(e -> dispose());

        // Add components to the panel
        mainPanel.add(Box.createVerticalStrut(20));
        label1.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label1);
        mainPanel.add(Box.createVerticalStrut(10));
        label2.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label2);
        label3.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label3);
        label4.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label4);
        mainPanel.add(Box.createVerticalStrut(10));
        label5.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label5);
        textField1.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(textField1);
        mainPanel.add(Box.createVerticalStrut(10));
        label6.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label6);
        textField2.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(textField2);
        mainPanel.add(Box.createVerticalStrut(10));
        label7.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label7);
        label8.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label8);
        label9.setAlignmentX(Component.CENTER_ALIGNMENT); mainPanel.add(label9);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(exitButton);

        setContentPane(mainPanel);
    }

    /**
     * Panel with a watermark for the background.
     */
    class WatermarkPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Background color
            g.setColor(new Color(37, 40, 48));
            g.fillRect(0, 0, getWidth(), getHeight());
            // Watermark
            Graphics2D g2d = (Graphics2D) g.create();
            String watermark = "AES-256-GCM";
            Font font = new Font("Arial", Font.BOLD, 80);
            g2d.setFont(font);
            FontMetrics fm = g2d.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(watermark)) / 2;
            int y = (getHeight() + fm.getAscent()) / 2 - 70;
            g2d.setColor(new Color(70, 130, 180, 35));
            g2d.drawString(watermark, x, y);
            g2d.dispose();
        }
    }

    /**
     * Creates a JLabel with a dark theme.
     *
     * @param text Text for the label.
     * @return The styled JLabel.
     */
    private JLabel createDarkLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.PLAIN, 15));
        return label;
    }

    /**
     * Creates a non-editable JTextField with a dark theme.
     *
     * @param value Default value for the field.
     * @return The styled JTextField.
     */
    private JTextField createDarkTextField(String value) {
        JTextField tf = new JTextField(value);
        tf.setEditable(false);
        tf.setBackground(new Color(44, 47, 56));
        tf.setForeground(Color.WHITE);
        tf.setFont(new Font("Consolas", Font.PLAIN, 13));
        tf.setBorder(BorderFactory.createLineBorder(new Color(90, 90, 90)));
        tf.setMaximumSize(new Dimension(700, 28));
        return tf;
    }

    /**
     * Styles a JButton in a dark theme.
     *
     * @param button The button to be styled.
     */
    private void styleDarkButton(JButton button) {
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
    }
}