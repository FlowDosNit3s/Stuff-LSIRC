package ui;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
import crypto.AESCipher;
import crypto.KeyDerivation;

/**
 * Main window for the AES-256-GCM encryptor/decryptor application.
 * <p>
 * This class provides a graphical user interface for encryption and decryption of files and text using AES-256-GCM.
 * It supports drag & drop and file selection, custom dark-themed appearance, and is internationalized for English.
 * <ul>
 *     <li>Encrypt and decrypt files using a password-derived key.</li>
 *     <li>Encrypt and decrypt text via a simple panel.</li>
 *     <li>Provides user feedback and custom visual branding.</li>
 *     <li>Supports drag-and-drop, file chooser dialogs, and displays selected files in a table view.</li>
 * </ul>
 *
 * @author Diogo Fernando Águia Costa
 * Number: 8240696
 * Class: LSIRC T1
 */
public class MainWindow extends JFrame {

    private final List<String> droppedFiles = new ArrayList<>();
    private JLabel selectedFilesLabel;
    private JPasswordField fileKeyField;
    private JPasswordField textKeyField;
    private JTextArea inputTextArea;
    private JTextArea outputTextArea;

    /**
     * Custom panel displaying the watermark, title, and visual effects.
     */
    class WatermarkPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            int w = getWidth(), h = getHeight();

            // Modern gradient background
            Color color1 = new Color(37, 40, 48);
            Color color2 = new Color(44, 47, 56);
            GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);

            // Watermark: CENTRAL TITLE
            String aes = "AES-256";
            String gcm = "GCM";
            String subtitle = "Information Security";

            // Extra large fonts!
            Font fontTitle = new Font("Arial Black", Font.BOLD, Math.min(130, Math.max(72, w / 8)));
            Font fontGCM = new Font("Arial Black", Font.BOLD, Math.max(44, fontTitle.getSize() / 2));
            Font fontSub = new Font("Segoe UI", Font.BOLD, 28);

            g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            // TITLE
            g2d.setFont(fontTitle);
            FontMetrics fmTitle = g2d.getFontMetrics();
            int totalTitleWidth = fmTitle.stringWidth(aes);

            // GCM logo to the side, slightly smaller
            g2d.setFont(fontGCM);
            FontMetrics fmGCM = g2d.getFontMetrics();
            int gcmWidth = fmGCM.stringWidth(gcm);

            int totalWidth = totalTitleWidth + 34 + gcmWidth + 80; // space + room for lock
            int x = (w - totalWidth) / 2;
            int y = (h + fmTitle.getAscent()) / 2 - 60;

            // Double shadow effect
            g2d.setFont(fontTitle);
            g2d.setColor(new Color(0, 0, 0, 92));
            g2d.drawString(aes, x + 6, y + 8); // heavy shadow
            g2d.setColor(new Color(0, 0, 0, 54));
            g2d.drawString(aes, x + 2, y + 3);

            // Gradient AES-256 text
            GradientPaint tp = new GradientPaint(x, y, new Color(65, 130, 200, 145), x + totalTitleWidth, y, new Color(160, 200, 255, 155), true);
            g2d.setPaint(tp);
            g2d.drawString(aes, x, y);

            // GCM – right side, a bit lower
            int gcmX = x + totalTitleWidth + 34;

            // GCM shadow
            g2d.setFont(fontGCM);
            g2d.setColor(new Color(0, 0, 0, 112));
            g2d.drawString(gcm, gcmX + 5, y + 12);

            // GCM gradient
            GradientPaint gpGCM = new GradientPaint(gcmX, y, new Color(85, 175, 255, 130), gcmX + gcmWidth, y, new Color(180, 220, 255, 150), true);
            g2d.setPaint(gpGCM);
            g2d.drawString(gcm, gcmX, y + 8);

            // Stylized padlock – large, with highlight
            int iconSize = fontGCM.getSize() + 18;
            int iconX = gcmX + gcmWidth + 30;
            int iconY = y - iconSize + 24;
            drawPadlock(g2d, iconX, iconY, iconSize, new Color(65, 150, 205, 78));

            // Subtitle, centered at bottom
            g2d.setFont(fontSub);
            FontMetrics subFm = g2d.getFontMetrics();
            int subX = (w - subFm.stringWidth(subtitle)) / 2;
            int subY = y + Math.max(fontTitle.getSize() / 2, 64);
            g2d.setColor(new Color(220, 220, 250, 58));
            g2d.drawString(subtitle, subX, subY);

            g2d.dispose();
        }

        /**
         * Draws a stylized padlock with highlighting.
         */
        private void drawPadlock(Graphics2D g2d, int x, int y, int size, Color color) {
            int bodyW = size / 2, bodyH = size / 2;
            int arc = size / 5;

            // Main body
            g2d.setColor(color);
            g2d.fillRoundRect(x, y + size / 3, bodyW, bodyH, arc, arc);

            // Highlight (oval semi-transparent)
            g2d.setColor(new Color(255, 255, 255, 27));
            g2d.fillOval(x + bodyW / 4, y + size / 2, bodyW / 2, bodyH / 3);

            // Padlock arc
            g2d.setColor(color.darker());
            g2d.setStroke(new BasicStroke((float) size / 12, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2d.drawArc(x, y, bodyW, bodyH, 0, 180);

            // Center (lock hole)
            g2d.setColor(new Color(0, 0, 0, 48));
            g2d.fillOval(x + bodyW / 2 - size / 18, y + size / 2 + size / 8, size / 12, size / 10);
        }
    }

    /**
     * Constructs the main window and its panels.
     */
    public MainWindow() {
        setTitle("AES-256-GCM Encryptor / Decryptor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(980, 650));
        setLocationRelativeTo(null);

        setJMenuBar(createMenuBar());

        WatermarkPanel mainPanel = new WatermarkPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(22, 18, 18, 18));

        JPanel filesPanel = createFilePanel();
        filesPanel.setOpaque(false);
        mainPanel.add(filesPanel);

        mainPanel.add(Box.createVerticalStrut(16));

        JPanel textPanel = createTextPanel();
        textPanel.setOpaque(false);
        mainPanel.add(textPanel);

        add(mainPanel);
        pack();
    }

    /**
     * Creates and configures the application menu bar.
     * @return The JMenuBar for this window.
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(37, 40, 48));
        menuBar.setBorder(BorderFactory.createEmptyBorder());
        menuBar.setOpaque(true);

        JMenu fileMenu = new JMenu("File");
        fileMenu.setForeground(Color.BLACK);

        JMenuItem selectFilesItem = new JMenuItem("Select File");
        JMenuItem showSelectedFilesItem = new JMenuItem("Selected Files");
        JMenuItem exitItem = new JMenuItem("Exit");

        fileMenu.add(selectFilesItem);
        fileMenu.add(showSelectedFilesItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setForeground(Color.BLACK);
        JMenuItem aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(helpMenu);

        selectFilesItem.addActionListener(e -> selectFiles());
        showSelectedFilesItem.addActionListener(e -> showSelectedFiles());
        exitItem.addActionListener(e -> System.exit(0));
        aboutItem.addActionListener(e -> new AboutDialog(this).setVisible(true));

        return menuBar;
    }

    /**
     * Creates the panel for file selection, drag & drop, and file encryption/decryption controls.
     * @return JPanel with file controls.
     */
    private JPanel createFilePanel() {
        JPanel roundedPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(44,47,56, 200));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 26, 26);
                g2.dispose();
            }
        };
        roundedPanel.setOpaque(false);
        roundedPanel.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        JPanel content = new JPanel(new GridBagLayout());
        content.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.fill = GridBagConstraints.BOTH;

        // Left side: Drag & Drop
        JPanel left = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(70, 130, 180, 30));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
            }
        };
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        JLabel dragLabel = createLabel("Drag and drop files here", 18, true);
        dragLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel ouLabel = createLabel("or", 13, false);
        ouLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton selectBtn = new JButton("Select Files");
        styleButton(selectBtn);
        selectBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        left.add(Box.createVerticalStrut(10));
        left.add(dragLabel);
        left.add(Box.createVerticalStrut(7));
        left.add(ouLabel);
        left.add(Box.createVerticalStrut(5));
        left.add(selectBtn);
        left.add(Box.createVerticalGlue());

        left.setPreferredSize(new Dimension(250,120));

        left.setDropTarget(new DropTarget() {
            @Override
            public synchronized void drop(DropTargetDropEvent evt) {
                try {
                    evt.acceptDrop(DnDConstants.ACTION_COPY);
                    droppedFiles.clear();
                    List<File> files = (List<File>) evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : files) {
                        droppedFiles.add(file.getAbsolutePath());
                    }
                    selectedFilesLabel.setText("Selected files: " + droppedFiles.size());
                } catch (Exception e) {
                    showError("Error importing files: " + e.getMessage());
                }
            }
        });
        selectBtn.addActionListener(e -> selectFiles());

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.34;
        content.add(left, gbc);

        // Right side: Info, key, action buttons
        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.add(Box.createVerticalStrut(12));
        selectedFilesLabel = createLabel("Selected files: 0", 15, true);
        selectedFilesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        right.add(selectedFilesLabel);
        right.add(Box.createVerticalStrut(12));

        JPanel fileKeyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fileKeyPanel.setOpaque(false);
        JLabel fileKeyLabel = createLabel("Secret key:", 14, false);
        fileKeyField = new JPasswordField(12);
        styleField(fileKeyField);
        fileKeyPanel.add(fileKeyLabel);
        fileKeyPanel.add(fileKeyField);
        fileKeyPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        right.add(fileKeyPanel);
        right.add(Box.createVerticalStrut(18));

        JPanel fileBtnPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        fileBtnPanel.setOpaque(false);
        JButton fileEncBtn = new JButton("Encrypt");
        JButton fileDecBtn = new JButton("Decrypt");
        styleAltButton(fileEncBtn, true);
        styleAltButton(fileDecBtn, false);
        fileBtnPanel.add(fileEncBtn);
        fileBtnPanel.add(fileDecBtn);
        fileBtnPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        right.add(fileBtnPanel);
        right.add(Box.createVerticalGlue());

        fileEncBtn.addActionListener(e -> encryptFiles());
        fileDecBtn.addActionListener(e -> decryptFiles());

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.66;
        content.add(right, gbc);

        roundedPanel.add(content, BorderLayout.CENTER);
        return roundedPanel;
    }

    /**
     * Creates the panel containing text encryption/decryption controls.
     * @return JPanel with text areas and controls for text input/output.
     */
    private JPanel createTextPanel() {
        JPanel roundedPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(44,47,56, 230));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        roundedPanel.setOpaque(false);
        roundedPanel.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        JPanel mainContent = new JPanel();
        mainContent.setOpaque(false);
        mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.X_AXIS));

        JPanel textAreasPanel = new JPanel();
        textAreasPanel.setOpaque(false);
        textAreasPanel.setLayout(new BoxLayout(textAreasPanel, BoxLayout.Y_AXIS));

        JLabel inputLabel = createLabel("Enter the text:", 13, true);
        inputLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        inputTextArea = new JTextArea();
        inputTextArea.setLineWrap(true);
        inputTextArea.setWrapStyleWord(true);
        styleTextArea(inputTextArea);
        JScrollPane inputScroll = new JScrollPane(inputTextArea);
        inputScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        inputScroll.setPreferredSize(new Dimension(0, 80));
        inputScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        inputScroll.setBorder(BorderFactory.createLineBorder(new Color(70,130,180, 60), 1, true));

        JLabel resultLabel = createLabel("Result:", 13, true);
        resultLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        outputTextArea = new JTextArea();
        outputTextArea.setLineWrap(true);
        outputTextArea.setWrapStyleWord(true);
        outputTextArea.setEditable(false);
        styleTextArea(outputTextArea);
        JScrollPane outputScroll = new JScrollPane(outputTextArea);
        outputScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        outputScroll.setPreferredSize(new Dimension(0, 80));
        outputScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        outputScroll.setBorder(BorderFactory.createLineBorder(new Color(70,130,180, 60), 1, true));

        textAreasPanel.add(inputLabel);
        textAreasPanel.add(inputScroll);
        textAreasPanel.add(Box.createVerticalStrut(10));
        textAreasPanel.add(resultLabel);
        textAreasPanel.add(outputScroll);

        mainContent.add(textAreasPanel);

        JPanel sidePanel = new JPanel();
        sidePanel.setOpaque(false);
        sidePanel.setLayout(new BoxLayout(sidePanel, BoxLayout.Y_AXIS));
        sidePanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

        JPanel textKeyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        textKeyPanel.setOpaque(false);
        JLabel textKeyLabel = createLabel("Secret key:", 14, false);
        textKeyField = new JPasswordField(12);
        styleField(textKeyField);
        textKeyPanel.add(textKeyLabel);
        textKeyPanel.add(textKeyField);

        JPanel textBtnPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        textBtnPanel.setOpaque(false);
        JButton textEncBtn = new JButton("Encrypt");
        JButton textDecBtn = new JButton("Decrypt");
        styleAltButton(textEncBtn, true);
        styleAltButton(textDecBtn, false);
        textBtnPanel.add(textEncBtn);
        textBtnPanel.add(textDecBtn);

        sidePanel.add(textKeyPanel);
        sidePanel.add(Box.createVerticalStrut(10));
        sidePanel.add(textBtnPanel);
        sidePanel.add(Box.createVerticalGlue());

        textEncBtn.addActionListener(e -> encryptText());
        textDecBtn.addActionListener(e -> decryptText());

        mainContent.add(sidePanel);

        roundedPanel.add(mainContent, BorderLayout.CENTER);
        return roundedPanel;
    }

    // Utility and style methods, followed by encryption/decryption logic and UI actions...

    /**
     * Creates a JLabel with specific font size and style.
     */
    private JLabel createLabel(String text, int size, boolean bold) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", bold ? Font.BOLD : Font.PLAIN, size));
        return label;
    }

    /**
     * Styles input and password fields.
     */
    private void styleField(JTextComponent field) {
        field.setBackground(new Color(44, 47, 56));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setFont(new Font("Consolas", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createLineBorder(new Color(90, 90, 90, 120), 1, true));
    }

    /**
     * Styles regular text areas.
     */
    private void styleTextArea(JTextArea ta) {
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBackground(new Color(34, 36, 43));
        ta.setForeground(Color.WHITE);
        ta.setCaretColor(Color.WHITE);
        ta.setFont(new Font("Consolas", Font.PLAIN, 15));
        ta.setBorder(BorderFactory.createEmptyBorder(7, 9, 7, 9));
    }

    /**
     * Styles main action buttons (for file selection, etc.).
     */
    private void styleButton(JButton button) {
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 22, 8, 22));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(220,40));
        button.setPreferredSize(new Dimension(220,40));
    }

    /**
     * Styles alternate color buttons (Encrypt/Decrypt).
     */
    private void styleAltButton(JButton button, boolean enc) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        if (enc) {
            button.setBackground(new Color(34, 133, 90));
        } else {
            button.setBackground(new Color(196, 68, 54));
        }
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(120,40));
        button.setPreferredSize(new Dimension(120,40));
    }

    /**
     * Styles menu items (not used in this file version).
     */
    private void styleMenuItem(JMenuItem item) {
        item.setBackground(new Color(44,47,56));
        item.setForeground(Color.WHITE);
        item.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    /**
     * Shows an error dialog for the user.
     */
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Shows an informational dialog for the user.
     */
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Encrypts all files currently selected. Outputs ".enc" files.
     */
    private void encryptFiles() {
        if (droppedFiles.isEmpty()) {
            showError("No file selected.");
            return;
        }
        char[] password = fileKeyField.getPassword();
        if (password.length == 0) {
            showError("Please enter the secret key.");
            return;
        }
        try {
            byte[] key = KeyDerivation.deriveKey(password);
            for (String path : droppedFiles) {
                byte[] data = Files.readAllBytes(Paths.get(path));
                byte[] encrypted = AESCipher.encryptBytes(data, key);
                Files.write(Paths.get(path + ".enc"), encrypted);
            }
            showInfo("Files encrypted successfully!");
        } catch (Exception ex) {
            showError("Error encrypting files: " + ex.getMessage());
        }
    }

    /**
     * Decrypts all files currently selected. Removes ".enc" or adds ".dec" depending on the filename.
     */
    private void decryptFiles() {
        if (droppedFiles.isEmpty()) {
            showError("No file selected.");
            return;
        }
        char[] password = fileKeyField.getPassword();
        if (password.length == 0) {
            showError("Please enter the secret key.");
            return;
        }
        try {
            byte[] key = KeyDerivation.deriveKey(password);
            for (String path : droppedFiles) {
                byte[] data = Files.readAllBytes(Paths.get(path));
                byte[] decrypted = AESCipher.decryptBytes(data, key);
                String outPath = path.endsWith(".enc") ? path.substring(0, path.length() - 4) : path + ".dec";
                Files.write(Paths.get(outPath), decrypted);
            }
            showInfo("Files decrypted successfully!");
        } catch (Exception ex) {
            showError("Error decrypting files: " + ex.getMessage());
        }
    }

    /**
     * Encrypts the text from the input field, puts result in output area.
     */
    private void encryptText() {
        String text = inputTextArea.getText();
        char[] password = textKeyField.getPassword();
        if (text.isEmpty() || password.length == 0) {
            showError("Please enter the text and the secret key.");
            return;
        }
        try {
            byte[] key = KeyDerivation.deriveKey(password);
            String encrypted = AESCipher.encryptText(text, key);
            outputTextArea.setText(encrypted);
        } catch (Exception ex) {
            showError("Error encrypting text: " + ex.getMessage());
        }
    }

    /**
     * Decrypts the text from the input field, puts result in output area.
     */
    private void decryptText() {
        String text = inputTextArea.getText();
        char[] password = textKeyField.getPassword();
        if (text.isEmpty() || password.length == 0) {
            showError("Please enter the text and the secret key.");
            return;
        }
        try {
            byte[] key = KeyDerivation.deriveKey(password);
            String decrypted = AESCipher.decryptText(text, key);
            outputTextArea.setText(decrypted);
        } catch (Exception ex) {
            showError("Error decrypting text: " + ex.getMessage());
        }
    }

    /**
     * Shows a simple dialog listing currently selected files.
     */
    private void showSelectedFiles() {
        if (droppedFiles.isEmpty()) {
            showInfo("No file selected");
            return;
        }
        JFrame frame = new JFrame("Selected files");
        JTable table = new JTable(droppedFiles.size(), 1);
        for (int i = 0; i < droppedFiles.size(); i++) {
            table.setValueAt(droppedFiles.get(i), i, 0);
        }
        frame.add(new JScrollPane(table));
        frame.pack();
        // substitua esta linha:
        // frame.setLocationRelativeTo(this);

        // por exemplo, para mostraro frame mais à direita da tela:
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) (screenSize.width * 0.75); // 75% do lado esquerdo, perto da borda direita
        int y = (int) (screenSize.height * 0.25); // 25% da altura do topo
        frame.setLocation(x, y);
        frame.setVisible(true);
    }

    /**
     * Opens a file chooser dialog, updating the selected file list and UI label.
     */
    private void selectFiles() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setMultiSelectionEnabled(true);
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            droppedFiles.clear();
            for (File file : fileChooser.getSelectedFiles()) {
                droppedFiles.add(file.getAbsolutePath());
            }
            selectedFilesLabel.setText("Selected files: " + droppedFiles.size());
        }
    }

    /**
     * Application entry point.
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}